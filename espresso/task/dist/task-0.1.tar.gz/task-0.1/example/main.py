from espresso.task.ecutconverger import EcutConverger
from espresso.task.kconverger import KConverger


#k_opt = KConverger('config.ini')

e_opt = EcutConverger('config.ini')

