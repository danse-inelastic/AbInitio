from distutils.core import setup
setup(name='task',
      version='0.1',
      packages=['task'],
      package_dir={'task': 'src'},
      description='Quantum Espresso launchers',
      )
